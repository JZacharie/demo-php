# Extending

The bundle architecture provides several extension possibilities for developers to customize the behaviour.
Beside standard symfony extension and customization possibilities, there are two more specific options for extending: 

- [Extend via Custom Strategies](./01_Extend_Custom_Strategies.md)
- [Events](./03_Events.md)
